const express = require('express');

const app = express();

const port = 3000;

const pokemon = 'database';

app.get('/pokemon', (req, res) => { //this will never be reached
    res.send(`
      <h1>pokemon</h1>
         `);
});

app.get('/', (req, res) => { //this will never be reached
    res.send(`
      <h1>PWelcome to the Pokemon App!</h1>
         `);
});







app.listen(port, () => {
    console.log('listening on port', port);
});